import streamlit as st
import pandas as pd
import plotly.figure_factory as ff
import plotly.express as px
import plotly.graph_objs as go


from sklearn.preprocessing import MinMaxScaler
import yfinance as yf
import matplotlib.pyplot as plt
# from statsmodels.tsa.seasonal import seasonal_decompose
from sklearn.linear_model import LinearRegression
# from lightgbm import LGBMRegressor
import statistics as s
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")



import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

import warnings
warnings.filterwarnings("ignore")
sns.set_style("darkgrid", {"grid.color": ".6",
						"grid.linestyle": ":"})

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Lasso

from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import GridSearchCV

def yfinance_data(id:str,table_name:str,col_name:str):
  abc= yf.Ticker(id)
  table_name= pd.DataFrame(abc.history(period='10Y',interval="1d"))
  table_name=table_name.reset_index()
  table_name['Date']=pd.to_datetime(table_name['Date'])
  table_name['Date']=pd.to_datetime(table_name["Date"].dt.date)
  table_name[col_name]=None
  for i in range(len(table_name)):
    table_name[col_name][i]=(int(table_name['High'][i])+int(table_name['Low'][i]))/2
  return table_name[["Date",col_name]]


def get_df():
    global df

    

    gold_data=yfinance_data("GC=F","gold_data","Gold_price")
    spx_data=yfinance_data("^SPX","spxt","SPX500")
    dollar_index=yfinance_data("DX-Y.NYB","usd","Dollar_Index")
    nifty=yfinance_data("^NSEI","nifty","Nifty50")
    platinum=yfinance_data("PL=F","platinum","Platinum")
    silver=yfinance_data("SI=F","silver","Silver")
    b_oil=yfinance_data("BZ=F","brent_oil","Brent_oil")
    c_oil=yfinance_data("CL=F","Crude_oil","Crude_oil")

    # print("done")

    import fredapi as fa
    import pandas as pd
    import time

    fredapi = '756ec67357f40d49bc6117e90b3a3dc9'
    fred = fa.Fred(api_key=fredapi)

    def fred_data():
        global gdp,unemployementRate,cpi,housing,auto_sale,retail_sale,intrest_rate

        gdp = (fred.get_series('GDP')).tail(40).reset_index()
        gdp.columns = ['Date', 'GDP']
        gdp['Date'] = pd.to_datetime(gdp['Date'])


        # time.sleep(2)



        unemployementRate = (fred.get_series('UNRATE')).tail(120).reset_index()
        unemployementRate.columns = ['Date', 'UnemployementRate']
        unemployementRate['Date'] = pd.to_datetime(unemployementRate['Date'])

        # time.sleep(2)



        cpi = (fred.get_series('CPALTT01USM657N')).tail(120).reset_index()
        cpi.columns = ['Date', 'CPI']
        cpi['Date'] = pd.to_datetime(cpi['Date'])

        # time.sleep(2)


        housing = (fred.get_series('HOSINVUSM495N')).tail(120).reset_index()
        housing.columns = ['Date', 'Housing']
        housing['Date'] = pd.to_datetime(housing['Date'])

        # time.sleep(2)


        auto_sale = (fred.get_series('TOTALSA')).tail(120).reset_index()
        auto_sale.columns = ['Date', 'Auto_sale']
        auto_sale['Date'] = pd.to_datetime(auto_sale['Date'])

        # time.sleep(2)


        retail_sale = (fred.get_series('RSXFS')).tail(120).reset_index()
        retail_sale.columns = ['Date', 'Retail_sale']
        retail_sale['Date'] = pd.to_datetime(retail_sale['Date'])

        # time.sleep(2)


        intrest_rate = (fred.get_series("DFF")).tail(3650).reset_index()
        intrest_rate.columns = ['Date', 'FED']
        intrest_rate['Date'] = pd.to_datetime(intrest_rate['Date'])

        # time.sleep(2)



    fred_data()


    df=pd.DataFrame ({'Date': pd.date_range(start=gold_data['Date'][0], end=gold_data['Date'].iloc[-1])})
    df_to_merge=[gold_data,spx_data,dollar_index,nifty,gdp,unemployementRate,cpi,housing,auto_sale,retail_sale,intrest_rate,silver,platinum,b_oil,c_oil]
    for i in df_to_merge[:]:
        for j in range(len(i)):
            if pd.isna(i.iloc[:,1][j])==False:
                i.iloc[:,1][j]=float(i.iloc[:,1][j])
        df = pd.merge(df, i, on='Date', how='outer')

    df=df.ffill()
    df=df.bfill()
    print(df)
    df.to_csv("data\\df_data.csv",index=False)
    st.toast(' Succesfully loaded ', icon="✅")
    time.sleep(0.5)

    
def compare_page():

  load_data=st.button("Load Data")

  if load_data:
      get_df()
  df=pd.read_csv("data\df_data.csv")
  options = st.multiselect(
      'Select the factors',
      ['Gold_price', 'SPX500', 'Dollar_Index', 'Nifty50', 'GDP',
        'UnemployementRate', 'CPI', 'Housing', 'Auto_sale', 'Retail_sale',
        'FED', 'Silver', 'Platinum', 'Brent_oil', 'Crude_oil']
      )


  st.write("Factors selected")
  st.code(options)
  analyise=st.button("Analyze")
  if analyise:
    corr_matrix = df[options].corr()

    # Plotly heatmap
    fig = ff.create_annotated_heatmap(z=corr_matrix.values,
                                      x=list(corr_matrix.columns),
                                      y=list(corr_matrix.index),
                                      colorscale='BrBG',
                                      
                                      showscale=True)

    # Update layout for better display
  
  
    
    # Display the heatmap in Streamlit

    
  # Display the plot in Streamlit


    st.header('Correlation Map', divider='rainbow')
    st.plotly_chart(fig)
    st.header("Descriptive Statistics ",divider='rainbow')
    st.table(df.describe())
    figl = go.Figure()
    scaler = MinMaxScaler()
    normalized_data = scaler.fit_transform(df[options])
    normalized_df = pd.DataFrame(normalized_data, columns=options)

    for col in options:
      if col != 'Date':
        figl.add_trace(go.Scatter(x=df['Date'], y=normalized_df[col], mode='lines', name=col))


    figl.update_layout( xaxis_title='Date', yaxis_title='Value')
    st.header("line Plot ",divider='rainbow')

    # Display the Plotly figure using Streamlit
    st.plotly_chart(figl)
    




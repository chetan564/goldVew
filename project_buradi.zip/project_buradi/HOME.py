import streamlit as st
import requests
# from live_gp import *
import pandas as pd
from pred import *
from news import *
from chintu import chat_bot
from forecast import *
from datetime import datetime



import time
    
# from streamlit_lottie import st_lottie

import json

# Load the JSON file

if 'hclicked' not in st.session_state:
    st.session_state.hclicked = False
if 'cclicked' not in st.session_state:
    st.session_state.cclicked = False

if 'fclicked' not in st.session_state:
    st.session_state.fclicked = False
if 'clicked' not in st.session_state:
    st.session_state.clicked = False

if 'nclicked' not in st.session_state:
    st.session_state.nclicked = False

if 'news_inner_button_clicked' not in st.session_state:
        st.session_state.news_inner_button_clicked = False

def click_button_chintu():
  st.session_state.clicked =True
  st.session_state.fclicked = False
  st.session_state.nclicked=False
  # st.session_state.hclicked=False
  st.session_state.cclicked=False

def click_button_forecast():
    st.session_state.fclicked = True
    st.session_state.clicked=False
    st.session_state.nclicked=False
    # st.session_state.hclicked=False
    st.session_state.cclicked=False


def click_button_news():
  st.session_state.clicked =False
  st.session_state.fclicked = False
  st.session_state.nclicked=True
  # st.session_state.hclicked=False
  st.session_state.cclicked=False
def click_button_home():
  st.session_state.clicked =False
  st.session_state.fclicked = False
  st.session_state.nclicked=False
  # st.session_state.hclicked=True
  st.session_state.cclicked=False
def click_button_compare():
  st.session_state.clicked =False
  st.session_state.fclicked = False
  st.session_state.nclicked=False
  # st.session_state.hclicked=False
  st.session_state.cclicked=True
def analyz_button():
    st.session_state.news_inner_button_clicked =True
    st.session_state.clicked =False
    st.session_state.fclicked = False
    st.session_state.nclicked=True
    # st.session_state.hclicked=False
    st.session_state.cclicked=False







st.set_page_config(page_title="GoldVue",layout="wide" ,page_icon="👑",menu_items={"About":None})


# with open("animation_llngvtww\data.json", "r") as f:
#     lottie_json = json.load(f)
# st_lottie(lottie_json,loop=False,)
# # Stop the animation after 2 seconds
# time.sleep(3)






st.sidebar.markdown('<div style="display:block;font-size: 36px;font-weight: bold;padding: 0px 20px 0px 20px;border: 2px outset rgb(247, 189, 0);letter-spacing: 5PX;color: #FFD670;text-align: center; text-shadow: 2px 2px 4px #000000;border-radius: 10px;box-shadow: 20px 20px 50px 10px rgba(5,5,5,1) inset;">GoldVue</div>', unsafe_allow_html=True)
#nav buttons
# if 'button' not in st.session_state:
#     st.session_state.button = False

# def click_button():
#     st.session_state.button = not st.session_state.button
st.sidebar.divider()
home=st.sidebar.button("Home",use_container_width=True,on_click=click_button_home,key="home")
compare=st.sidebar.button("compare",use_container_width=True,on_click=click_button_compare,key='compare')
frocaste=st.sidebar.button("Forecast",use_container_width=True,on_click=click_button_forecast, key="forecast")
news=st.sidebar.button("News",use_container_width=True,on_click=click_button_news,key='news')
chatBot=st.sidebar.button("Chintu(Chat_bot)",use_container_width=True,on_click=click_button_chintu,key="chintu")






gold_dollar = """



  <div  style="display: block;font-size: 30px;font-weight: bold;color: rgb(1000, 130, 0);word-spacing: 10PX;text-align: center;border: 2px outset rgb(247, 189, 0);background-color:rgba(5,5,5,0);padding: 0px 7px 0px 7px;border-radius: 10px; text-shadow: 2px 2px 2px rgba(5,5,5,0.02); ">Gold vs Dollar</div>

  <iframe  width="100%"  style="border:1px outset black;border-radius: 10px;margin:3px 0px 0px 0px; padding: 0px 3px 0px 3px" id="dollar_gold" valign="middle" margin="0px" width="888" height="680" marginheight="0" marginwidth="0" frameborder="0" vspace="0" hspace="0" scrolling="NO" src="https://www.macrotrends.net/assets/php/chart_iframe_comp.php?id=1335&amp;url=dollar-vs-gold-comparison-last-ten-years">
    
    """

gold_oil="""        


<div style="display: block;font-size: 30px;font-weight: bold;color: rgb(1000, 130, 0);word-spacing: 10PX;text-align: center;border: 2px outset rgb(247, 189, 0);background-color:rgba(5,5,5,0);padding: 0px 7px 0px 7px;border-radius: 10px; text-shadow: 2px 2px 2px rgba(5,5,5,0.02); ">Gold vs Oil</div>


<iframe width="100%"  style="border:1px outset black;border-radius: 10px;margin:3px 0px 0px 0px; padding: 0px 3px 0px 3px" id="chart_iframe" valign="middle" margin="0px" width="888" height="680" marginheight="0" marginwidth="0" frameborder="0" vspace="0" hspace="0" scrolling="NO" src="https://www.macrotrends.net/assets/php/chart_iframe_comp.php?id=1334&amp;url=gold-prices-vs-oil-prices-historical-correlation"></iframe>

"""
gold_price="""

    <div style="display: block;font-size: 30px;font-weight: bold;color: rgb(1000, 130, 0);word-spacing: 10PX;text-align: center;border: 2px outset rgb(247, 189, 0);background-color:rgba(5,5,5,0);padding: 0px 0px 0px 0px;border-radius: 10px; text-shadow: 2px 2px 2px rgba(5,5,5,0.02); ">Gold Spot Price</div>

   
  <iframe  width="100%"  style="border:1px outset black;border-radius: 10px;margin:3px 0px 0px 0px; padding: 0px 3px 0px 3px" id="chart_iframe" valign="middle" margin="0px" width="888" height="680" marginheight="0" marginwidth="0" frameborder="0" vspace="0" hspace="0" scrolling="NO" src="https://www.macrotrends.net/assets/php/chart_iframe_comp.php?id=2586&amp;url=gold-prices-today-live-chart"></iframe>


"""

gold_silver= """



  <div  style="display: block;font-size: 30px;font-weight: bold;color: rgb(1000, 130, 0);word-spacing: 10PX;text-align: center;border: 2px outset rgb(247, 189, 0);background-color:rgba(5,5,5,0);padding: 0px 7px 0px 7px;border-radius: 10px; text-shadow: 2px 2px 2px rgba(5,5,5,0.02); ">Gold vs Silver</div>

  <iframe id="chart_iframe" valign="middle" margin="0px" width="888" height="680" marginheight="0" marginwidth="0" frameborder="0" vspace="0" hspace="0" scrolling="NO" src="https://www.macrotrends.net/assets/php/chart_iframe_comp.php?id=2517&amp;url=gold-prices-vs-silver-prices-historical-chart"></iframe>
    
    """

gold_platinum= """



  <div  style="display: block;font-size: 30px;font-weight: bold;color: rgb(1000, 130, 0);word-spacing: 10PX;text-align: center;border: 2px outset rgb(247, 189, 0);background-color:rgba(5,5,5,0);padding: 0px 7px 0px 7px;border-radius: 10px; text-shadow: 2px 2px 2px rgba(5,5,5,0.02); ">Gold vs Platinum</div>

  <iframe id="chart_iframe" valign="middle" margin="0px" width="888" height="680" marginheight="0" marginwidth="0" frameborder="0" vspace="0" hspace="0" scrolling="NO" src="https://www.macrotrends.net/assets/php/chart_iframe_comp.php?id=2541&amp;url=platinum-prices-vs-gold-prices"></iframe>
    
    """

gold_stocks= """



  <div  style="display: block;font-size: 30px;font-weight: bold;color: rgb(1000, 130, 0);word-spacing: 10PX;text-align: center;border: 2px outset rgb(247, 189, 0);background-color:rgba(5,5,5,0);padding: 0px 7px 0px 7px;border-radius: 10px; text-shadow: 2px 2px 2px rgba(5,5,5,0.02); ">Gold vs Stocks Price</div>
<iframe id="chart_iframe" valign="middle" margin="0px" width="888" height="680" marginheight="0" marginwidth="0" frameborder="0" vspace="0" hspace="0" scrolling="NO" src="https://www.macrotrends.net/assets/php/chart_iframe_comp.php?id=2608&amp;url=gold-price-vs-stock-market-100-year-chart"></iframe>

  
    """


kitko_news="""




"""


hcol1, hcol2,hcol3 = st.columns([0.4, 0.3,0.3])
# st.write(gold_price, unsafe_allow_html=True)

if home:
  st.write("""<div style="display: block;margin: 0px 0px 30px 0px ;font-size: 30px;font-weight: bold;color: rgb(1000, 130, 0);word-spacing: 10PX;text-align: center;border: 2px outset rgb(247, 189, 0);background-color:rgba(5,5,5,0);padding: 0px 0px 0px 0px;border-radius: 10px; text-shadow: 2px 2px 2px rgba(5,5,5,0.02); ">Home</div>"""
,unsafe_allow_html=True)
  def get_current_GP():
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        'content-type': 'application/json',
        'origin': 'https://www.kitco.com',
        'pragma': 'no-cache',
        'priority': 'u=1, i',
        'referer': 'https://www.kitco.com/',
        'sec-ch-ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'x-query-id': '{"query":"MetalMonthAnnual(","variables":{"symbol":"AU","currency":"INR","timestamp":1713952800}}',
    }

    json_data = {
        'query': 'query MetalMonthAnnual( $symbol: String! $currency: String! $timestamp: Int! ) { GetHistoricalPoints( symbol: $symbol currency: $currency timestamp: $timestamp ) { ID now { ID bid ask low high change changePercentage } thirtyDay { ID change changePercentage } sixtyDay { ID change changePercentage } oneYear { ID change changePercentage } fiveYear { ID change changePercentage } } }',
        'variables': {
            'symbol': 'AU',
            'currency': 'INR',
            'timestamp': 1713952800,
        },
    }

    response = requests.post('https://kitco-gcdn-prod.stellate.sh/', headers=headers, json=json_data)


    current_gold_price=response.json()['data']['GetHistoricalPoints']["now"]
    return current_gold_price
  current_gold_price=get_current_GP()
  st.subheader("Current Gold Price",divider='rainbow')
  with st.container(border=True):
    col1,col2,col3=st.columns(3)
    with col1:
      current_time = datetime.now().strftime("%H:%M:%S")
      st.metric(label="Time",value=current_time)
    with col2:
      st.metric(label="Bid", value=current_gold_price['bid'])
    with col3:
      st.metric(label="Ask", value=current_gold_price['ask'])
    with col1:
      st.metric(label="Low", value=current_gold_price['low'])
    with col2:
      st.metric(label="High", value=current_gold_price['high'])
    with col3:
      st.metric(label="Change", value=current_gold_price['change'])
              
  st.subheader("Interactive Gold Price Graph",divider='rainbow')
  st.markdown("""<iframe title="advanced chart TradingView widget" lang="en" id="tradingview_56dfe" frameborder="0" allowtransparency="true" scrolling="no" allowfullscreen="true" src="https://s.tradingview.com/kitco/widgetembed/?hideideas=1&amp;overrides=%7B%7D&amp;enabled_features=%5B%5D&amp;disabled_features=%5B%5D&amp;locale=en#%7B%22symbol%22%3A%22XAUUSD%22%2C%22frameElementId%22%3A%22tradingview_56dfe%22%2C%22interval%22%3A%221%22%2C%22hide_side_toolbar%22%3A%221%22%2C%22allow_symbol_change%22%3A%221%22%2C%22save_image%22%3A%220%22%2C%22studies%22%3A%22%5B%5D%22%2C%22theme%22%3A%22light%22%2C%22style%22%3A%221%22%2C%22timezone%22%3A%22America%2FNew_York%22%2C%22withdateranges%22%3A%221%22%2C%22studies_overrides%22%3A%22%7B%7D%22%2C%22utm_source%22%3A%22www.kitco.com%22%2C%22utm_medium%22%3A%22widget_new%22%2C%22utm_campaign%22%3A%22chart%22%2C%22utm_term%22%3A%22XAUUSD%22%2C%22page-uri%22%3A%22www.kitco.com%2Fcharts%2Fgold%22%7D" style="width: 100%; height: 400px; margin: 0px !important; padding: 0px !important;"></iframe>""",unsafe_allow_html=True)


if st.session_state.cclicked:
  st.subheader("Factors Analysis",divider='rainbow')
  compare_page()

if news:
  news_page()



if st.session_state.fclicked:
  forecast_page()











if st.session_state.clicked:
  with st.container():
    chat_bot()




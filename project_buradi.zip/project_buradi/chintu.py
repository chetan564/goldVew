import google.generativeai as palm
import os
import time

import streamlit as st
import numpy as np

palm.configure(api_key='AIzaSyCmqp5fHNWQAwNT13W8xfGRR149j_hkfpk')
models = [m for m in palm.list_models() if 'generateText' in m.supported_generation_methods]
model = models[0].name


completion = palm.generate_text(
        model=model,
        prompt="your name is chintu",
        temperature=0,
     
        max_output_tokens=800,)

def get_prompt(text):
    completion = palm.generate_text(
        model=model,
        prompt=text,
        temperature=0,
     
        max_output_tokens=800,
    )
    return completion.result


def chat_bot():



    with st.chat_message("ai"):
            st.write("Hello..!! How may i assist you ? ")

    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat messages from history on app rerun
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    if prompt := st.chat_input("What is up?"):
        # Display user message in chat message container
        with st.chat_message("user"):
            st.markdown(prompt)
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        response = get_prompt(prompt)
        # Display assistant response in chat message container
        with st.chat_message("assistant"):
            st.markdown(response)
        # Add assistant response to chat history
        st.session_state.messages.append({"role": "assistant", "content": response})
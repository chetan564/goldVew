
import streamlit as st
import os
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv

load_dotenv()
google_api_key = os.getenv("GOOGLE_API_KEY")
llm = ChatGoogleGenerativeAI(model="gemini-pro")
print("hurray")



import requests
import pandas as pd
from bs4 import BeautifulSoup

llm = ChatGoogleGenerativeAI(model="gemini-pro")
def get_insights(url):
    response = requests.get(url)

    # Parse the HTML content of the webpage
    soup = BeautifulSoup(response.content, 'html.parser')

    # Find all <p> tags and extract their text
    p_tags = soup.find_all('p')

    # Extract text from each <p> tag and join them into a single string
    text = '\n'.join([p_tag.get_text() for p_tag in p_tags])

    # Print or do whatever you want with the extracted text
    # print(all_text_in_p_tags)

    result = llm.invoke(f"""can you please Extract all the numerical insights from given text below and return it in form of table. 
                    text: '{text}'   """)
    result2=llm.invoke(f"""Assume you are a Gold Buyer.Given a text about gold, Extract the good news and bad news (pointwise) by understanding the text. 

                    text: '{text}'   """)
    # print(result)
    return result.content,result2.content
    # return result.content
    # print(result)
    
# get_insights('https://www.kitco.com/news/article/2024-02-23/major-attack-us-infrastructure-now-its-highest-probability-brandon-weichert')
# print(result.content)



headers = {
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'no-cache',
    'content-type': 'application/json',
    'origin': 'https://www.kitco.com',
    'pragma': 'no-cache',
    'priority': 'u=1, i',
    'referer': 'https://www.kitco.com/',
    'sec-ch-ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
}

json_data = {
    'query': '\n            \n  fragment ArticleTeaserFragment on NewsArticle {\n    id\n    __typename\n    category {\n      id\n      name\n      urlAlias\n    }\n    teaserSnippet\n    title\n    teaserHeadline\n    urlAlias\n    source {\n      name\n      subtitle\n      description\n    }\n    audioTts {\n      isPublished\n      snippetUuid\n    }\n    createdAt\n    updatedAt\n    image {\n      ...ImageFragment\n    }\n    legacyThumbnailImageUrl\n  }\n\n            \n  fragment OffTheWireFragment on OffTheWire {\n    id\n    __typename\n    body\n    category {\n      id\n      name\n      urlAlias\n    }\n    title\n    teaserHeadline\n    teaserSnippet\n    urlAlias\n    source {\n      name\n      subtitle\n      description\n    }\n    createdAt\n    updatedAt\n    imageUrl\n    image {\n      ...ImageFragment\n    }\n    featured\n    legacyThumbnailImageUrl\n  }\n\n            \n  fragment ImageFragment on Image {\n    detail {\n      default {\n        srcset\n      }\n      sources {\n        teaser_small {\n          srcset\n          media\n        }\n        teaser_medium {\n          srcset\n          media\n        }\n        desktop {\n          media\n          srcset\n        }\n        mobile {\n          media\n          srcset\n        }\n        tablet {\n          media\n          srcset\n        }\n      }\n    }\n  }\n\n            \n  fragment CategoryFragment on Category {\n    id\n    name\n    urlAlias\n  }\n\n            query NewsByCategoryGeneric(\n              $urlAlias: String!\n              $limit: Int\n              $offset: Int\n              $includeRelatedCategories: Boolean\n              $includeEntityQueues: Boolean\n            ) {\n              nodeListByCategory(\n                limit: $limit\n                offset: $offset\n                urlAlias: $urlAlias\n                includeRelatedCategories: $includeRelatedCategories\n                includeEntityQueues: $includeEntityQueues\n              ) {\n                total\n                items {\n                  ... on NewsArticle {\n                    ...ArticleTeaserFragment\n                  }\n\n                  ... on OffTheWire {\n                    ...OffTheWireFragment\n                  }\n                  \n                  ... on Commentary {\n                    __typename\n                    title\n                    author {\n                      authorWebsite\n                      body\n                      email\n                      facebookId\n                      name\n                      imageUrl\n                      linkedInId\n                      title\n                      twitterId\n                      authorType\n                      urlAlias\n                      roles\n                    }\n                    bodyWithEmbeddedMedia {\n                      value\n                      embeddedMedia {\n                        assetUuid\n                        snippetUuid\n                        status\n                        startTime\n                        endTime\n                        type\n                        thumbnailUuid\n                      }\n                    }\n                    category {\n                      ...CategoryFragment\n                    }\n                    summaryBullets\n                    supportingAuthors {\n                      id\n                      name\n                      urlAlias\n                      imageUrl\n                      twitterId\n                      linkedInId\n                      email\n                      body\n                    }\n                    featuredContent {\n                      type\n                      assetUuid\n                      snippetUuid\n                      status\n                      startTime\n                      endTime\n                      thumbnailUuid\n                    }\n                    urlAlias\n                    source {\n                      id\n                      name\n                      description\n                      subtitle\n                    }\n                    teaserSnippet\n                    image {\n                      ...ImageFragment\n                    }\n                    audioTts {\n                      isPublished\n                      assetUuid\n                      status\n                      endTime\n                      startTime\n                    }\n                    tags {\n                      id\n                      name\n                      urlAlias\n                    }\n                    legacyThumbnailImageUrl\n                  }\n                }\n              }\n            }\n          ',
    'variables': {
        'limit': 20,
        'offset': 0,
        'urlAlias': '/news/category/commodities/gold',
    },
}

response = requests.post('https://cms.prod.kitco.com/graphql', headers=headers, json=json_data)
dff=pd.DataFrame(response.json()['data']['nodeListByCategory']['items'])
dff=dff[['title','teaserSnippet','updatedAt','urlAlias']]
dff['urlAlias'] = "https://www.kitco.com" + dff['urlAlias']
dff['updatedAt'] = pd.to_datetime(dff['updatedAt'])



dff['insights']=None
dff['summary']=None
for i in range(len(dff['urlAlias'])):
    res=get_insights(dff['urlAlias'][i])
    dff['insights'][i]=res[0]
    dff['summary'][i]=res[1]
    print(i)
dff.to_csv('data\\gold_news_insights.csv',index=False)

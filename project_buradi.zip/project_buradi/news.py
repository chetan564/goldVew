import streamlit as st
import pandas as pd


def news_page():
    dff=pd.read_csv("data\gold_news_insights.csv")


    news_page_header="""<div style="display: block;margin: 0px 0px 30px 0px ;font-size: 30px;font-weight: bold;color: rgb(1000, 130, 0);word-spacing: 10PX;text-align: center;border: 2px outset rgb(247, 189, 0);background-color:rgba(5,5,5,0);padding: 0px 0px 0px 0px;border-radius: 10px; text-shadow: 2px 2px 2px rgba(5,5,5,0.02); ">Gold News</div>"""

   
    st.write(news_page_header,unsafe_allow_html=True)
   
    for i in range(len(dff)):
        # with col1:
        

        with st.expander(f"{dff['title'][i]}   "):
            st.header(dff['title'][i])
            st.caption(f"Date: {dff['updatedAt'][i]}")
            st.subheader('Overview', divider='rainbow')
            st.write(dff['teaserSnippet'][i])
            st.subheader('Numerical Insights', divider='rainbow')
            st.write(dff['insights'][i])
            st.subheader('Pros and Cons', divider='rainbow')
            st.write(dff['summary'][i])

            # st.header('Insights', divider='rainbow')
            # st.code(df['other_metrices'][i])
            # st.button("Inner Button",key="aa"+str(i),on_click=analyz_button)
            # analyz=st.button("analyz",key=i,on_click=analyz_button)

            # if st.session_state.news_inner_button_clicked:
            #     st.write("Inner button was clicked!")
            
          
            st.link_button("Read More", dff['urlAlias'][i])
          

    

    


import streamlit as st
import pandas as pd
from prophet import Prophet

import streamlit as st
import plotly.express as px
import pandas as pd
import os
import warnings
import plotly.figure_factory as ff
import plotly.graph_objects as go
import datetime
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.graph_objs as go
f = go.FigureWidget()
import time

# if 'fclicked' not in st.session_state:
#     st.session_state.fclicked = False

# def click_button_f():
#     st.session_state.fclicked = True



# if st.session_state.clicked:
#     # The message and nested widget will remain on the page
#     st.write('Button clicked!')
#     st.slider('Select a value')





import yfinance as yf

warnings.filterwarnings('ignore') #this would remove any deprecated warning



def yfinance_data(id:str,table_name:str,col_name:str):
  abc= yf.Ticker(id)
  table_name= pd.DataFrame(abc.history(period='10Y',interval="1d"))
  table_name=table_name.reset_index()
  table_name['Date']=pd.to_datetime(table_name['Date'])
  table_name['Date']=pd.to_datetime(table_name["Date"].dt.date)
  table_name[col_name]=None
  for i in range(len(table_name)):
    table_name[col_name][i]=(int(table_name['High'][i])+int(table_name['Low'][i]))/2
  return table_name[["Date",col_name]]
gold_data=yfinance_data("GC=F","gold_data","gold_price")
spx_data=yfinance_data("^SPX","spxt","spx")
dollar_index=yfinance_data("DX-Y.NYB","usd","usd")
nifty=yfinance_data("^NSEI","nifty","nifty50")
platinum=yfinance_data("PL=F","platinum","plt")
silver=yfinance_data("SI=F","silver","slv")
b_oil=yfinance_data("BZ=F","brent_oil","b_oil")
c_oil=yfinance_data("CL=F","Crude_oil","c_oil")

df=pd.DataFrame ({'Date': pd.date_range(start=gold_data['Date'][0], end=gold_data['Date'].iloc[-1])})
df = pd.merge(df, gold_data, on='Date', how='outer')


df=df.ffill()
df=df.bfill()  
df=df.rename(columns={"Date":'ds',"gold_price":'y'})



def trail():
   st.title("thank you sexy")


def forecast_page():
  

    st.title('Interactive Forecasting Graph')
    days_forecast = st.number_input('no. of days to forecast')
    forecast_btn=st.button("Forecast")
    if forecast_btn:
        with st.spinner('generating forcasted data 📈📊'):
            time.sleep(5)
        model = Prophet()
        model.fit(df)
        future = model.make_future_dataframe(periods=int(days_forecast))
        future=future[len(df)-2:]
        


        forecast = model.predict(future)
        # st.write("Input DataFrame:")
        # st.write(df)
        st.write("Interactive Forecast Plot:")


        fig = go.Figure()
        fig.add_trace(go.Scatter(x=forecast['ds'], y=forecast['yhat'], mode='lines', name='Forecast' ))
        fig.add_trace(go.Scatter(x=df['ds'], y=df['y'], mode='lines', name='Actual' ))
        fig.update_layout(title='Forecast vs Actual', xaxis_title='Date', yaxis_title='Value')
        st.plotly_chart(fig)
        table_data=pd.DataFrame({"Date":forecast['ds'],"Forecast_Price":forecast["yhat"],},index=None)
        st.table(table_data)
        csv=table_data.to_csv().encode('utf-8')

        st.download_button(data=csv,label="Download Forecasted Data",file_name="Gold_Forecast_Data.csv",mime='text/csv',)




    
   

    # col1, col3,col2= st.columns([0.48,0.04,0.48])
    # # try:

    # with col2:

    #     end_date = st.date_input("End Date",min_value= df['Date'][0],max_value= df['Date'].iloc[-1],value=df['Date'].iloc[-1],format="YYYY-MM-DD")
                
        


    # with col1:
    #     start_date = st.date_input("Start Date",min_value= df['DATE'][0],max_value= df['DATE'].iloc[-1],value=datetime.date(2020, 3, 27),format="YYYY-MM-DD")
    #     filtered_data = df[(df['DATE'] >= start_date) & (df['DATE'] <= end_date)]
    #     bar_fig = go.Figure(data=[go.Bar(x=filtered_data['DATE'], y=filtered_data['GDP'], name='Bar Chart',hovertemplate='DATE: %{x}<br>GDP: %{y}')])

    #     bar_fig.add_trace(go.Scatter(x=filtered_data['DATE'], y=filtered_data['GDP'], mode='lines+markers', name='Line Chart'))
    #     st.plotly_chart(bar_fig, use_container_width=True)
    #     filtered_data['Month'] = filtered_data['DATE']
    #     st.table(filtered_data)
    #     @st.cache_data
    #     def convert_df(df):
    #         # IMPORTANT: Cache the conversion to prevent computation on every rerun
    #         return df.to_csv(index=False).encode('utf-8')

    #     csv = convert_df(filtered_data)

    #     st.download_button(
    #         label="Download data as CSV",
    #         data=csv,
    #         file_name='GDP_goldvue.csv',
    #         mime='text/csv',
    #     )

        
    #     with col2:
    #         dff=pd.DataFrame(pd.read_csv("gold_price.csv"))
            
        
    #         gold_filter_data=df[(df['ds'] >= start_date) & (df['ds'] <= end_date)]
    #         fig = px.line(gold_filter_data, x='ds', y='y', title='GOLD PRICE')
    #         st.plotly_chart(fig,use_container_width=True)
            # candle_fig= go.Figure(data=[go.Candlestick(x=filtered_data['DATE'], y=filtered_data['GDP'], name='Bar Chart',hovertemplate='DATE: %{x}<br>GDP: %{y}')])
            # candle_fig= go.Figure(data=[go.Candlestick(x=dff['Date'],
            #         open=dff['Open'],
            #         high=dff['High'],
            #         low=dff['Low'],
            #         close=dff['Close'])])
            # st.plotly_chart(candle_fig,use_container_width=True)
            # scatter=fig.data[0]
            # def update_point():
            #     print("hello")
            

            # scatter.on_click(update_point)
  

    
